python_counter.py is a module that includes the count_LOC() function.
the function recieves the path of the source file and returns a tuple with
the total number of lines in the source file as well as a dictionary mapping
each function to its LOC
