file_mean_stdev.py is a module that includes the calculate() function.
the function recieves the path of the file that contains the list of numbers to process
numbers in the file should come one per line
