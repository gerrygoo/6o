regression.py is a module that includes the three
required function.

source files are documented on usage and are to be interpreted
with python 3 interpreter.
